package com.pms;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/addproject")
@MultipartConfig(maxFileSize = 16177215, maxRequestSize=20000000)	// upload file's size up to 16MB

public class AddProject extends HttpServlet
{
	private String dbURL = "jdbc:mysql://localhost:3306/pms";
    private String dbUser = "root";
    private String dbPass = "";
    
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException 
    {
    	PrintWriter writer = response.getWriter();
    	
    	String MemName = request.getParameter("name");
        String Department = request.getParameter("Department");
        String ProjectName = request.getParameter("pname");
        int Year = Integer.parseInt(request.getParameter("year"));
        String Email = request.getParameter("email");
        String Descrip = request.getParameter("descrip");
        
        InputStream inputStreamH = null;
        InputStream inputStreamS = null;
        InputStream inputStreamT = null;
        InputStream inputStreamP = null;
        
        Part filePartH = request.getPart("himg");
        Part filePartS = request.getPart("simg");
        Part filePartT = request.getPart("timg");
        Part filePartP = request.getPart("pdf");
        
       if(filePartH != null)
       {
        if (filePartH.getSize() < 2097152) 
        {
        	
            inputStreamH = filePartH.getInputStream();
        }
        else
        {
        	writer.println("\n Invalid Home Page Image");
            return;
        }
       }
        
       if (filePartS != null)
       {
        if (filePartS.getSize() < 2097152 ) 
        {
        	 inputStreamS = filePartS.getInputStream();
        }
        else
        {
        	writer.println("\n Invalid Second Image");
            return;
        }
       }
       
       if (filePartT != null)
       {
        if (filePartT.getSize() < 2097152 ) 
        {
        	 inputStreamT = filePartT.getInputStream();
        }
        else
        {
        	writer.println("\n Invalid Third Image");
            return;
        }
       }
        
        if (!filePartP.getContentType().equals("application/pdf") && filePartP == null)
        {
                   writer.println("\n Invalid Pdf File");
                   
        }

       else if (filePartP.getSize()>10485760 )  //10mb
           {
          writer.println("\nPDF File size too big.");
          return;
           }
       
        
        	 inputStreamP = filePartP.getInputStream();
        	 byte[] bytes = new byte[inputStreamP.available()];
        	 inputStreamP.read(bytes);
        	
        String message = null;
        
        try {
            // connects to the database
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(dbURL, dbUser, dbPass);
            
            String sql = "INSERT INTO pregister (name, department, pname, year, email, descrip, pdf, himg, simg, timg) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            PreparedStatement pst = con.prepareStatement(sql);
            
            pst.setString(1, MemName);
            pst.setString(2, Department);
            pst.setString(3, ProjectName);
            pst.setInt(4, Year);
            pst.setString(5, Email);
            pst.setString(6, Descrip);
            
            pst.setBytes(7, bytes);
            
            pst.setBlob(8, inputStreamH);
            pst.setBlob(9, inputStreamS);
            pst.setBlob(10, inputStreamT);
            
            int row = pst.executeUpdate();
            if (row > 0) 
            {
                message = "Data and Files uploaded and saved successfully. </br> Thank You for Registering Your Project.\nIt will be uploaded on site after HOD approval.";
            }
        }
        catch (Exception ex) 
        {
            message = "ERROR: " + ex.getMessage();
            ex.printStackTrace();
        }
        
        request.setAttribute("Message", message);
        
        
        getServletContext().getRequestDispatcher("/Message.jsp").forward(request, response);
            
            
            
    	
    }
	
	

}
