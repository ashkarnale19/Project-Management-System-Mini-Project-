package com.pms;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Deleteproject")

public class Deleteproject extends HttpServlet
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	    String dbURL = "jdbc:mysql://localhost:3306/pms";
	    String dbUser = "root";
	    String dbPass = "";
	    
		String project = request.getParameter("project");
		String message = null;
		
		
		 
		if (project.equals("Delete Project")) 
		{
			HttpSession session = request.getSession();
			String department = (String)session.getAttribute("department");
			String pname = (String)session.getAttribute("projectname");
			
			 try {
		            // connects to the database
		            Class.forName("com.mysql.jdbc.Driver");
		            Connection con = DriverManager.getConnection(dbURL, dbUser, dbPass);
		            
		            String sql = "DELETE FROM project WHERE pname=? and department=?";
		            
		            PreparedStatement pst = con.prepareStatement(sql);
		            pst.setString(1, pname);
		            pst.setString(2, department);
		             
		            int row = pst.executeUpdate();
		            if (row > 0) 
		            {
		                message = "The Project is Deleted Succesfully.";
		            }
		        }
			 catch(Exception ex)
			 {
				 message = "ERROR: " + ex.getMessage();
		            ex.printStackTrace();
			 }
			
		} 
		
		 request.setAttribute("Message", message);
	        
	        
	        getServletContext().getRequestDispatcher("/MessageH.jsp").forward(request, response);
		    
		


	}
}