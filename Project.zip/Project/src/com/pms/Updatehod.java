package com.pms;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

@WebServlet("/updatehod")
@MultipartConfig(maxFileSize = 16177215)

public class Updatehod extends HttpServlet
{
	private String dbURL = "jdbc:mysql://localhost:3306/pms";
    private String dbUser = "root";
    private String dbPass = "";
    
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException 
    {
    	int count = 0;
    	 HttpSession session = request.getSession();
    	   String dept =(String) session.getAttribute("department");
    	   
    	   System.out.println(dept);
    	    
    	   PrintWriter writer = response.getWriter();
    	   
    	   String Name = request.getParameter("name");
           String Email = request.getParameter("email");
           String Uname = request.getParameter("uname");
           String Pass = request.getParameter("pass");
           
           String message = null;
           
           if (Name.isEmpty()== false ) 
           {
           	
              
               String sql = "Update hod set name = ? where department=? ";
               
                try {
                    // connects to the database
                    Class.forName("com.mysql.jdbc.Driver");
                    Connection con = DriverManager.getConnection(dbURL, dbUser, dbPass);
                    PreparedStatement pst = con.prepareStatement(sql);
                    
                    pst.setString(1, Name);
                    pst.setString(2, dept);
                    
                    System.out.println(Name);
                    
                    
                    int row = pst.executeUpdate();
                    if (row > 0) 
                    {
                        message = "HOD Name updated and saved successfully.";
                        count=count+1;
                    }
                    
                }
                catch(Exception ex)
                {
              	  message = "ERROR :"+ ex.getMessage() ;
              	  ex.printStackTrace();
                }  
           }
                if (Email.isEmpty()== false) 
                {
                	
                   
                    String sql1 = "Update hod set email = ? where department=?";
                    
                     try {
                         // connects to the database
                         Class.forName("com.mysql.jdbc.Driver");
                         Connection con = DriverManager.getConnection(dbURL, dbUser, dbPass);
                         PreparedStatement pst = con.prepareStatement(sql1);
                         
                         pst.setString(1, Email);
                         pst.setString(2, dept);
                         
                         System.out.println(Email);
                         
                         int row = pst.executeUpdate();
                         if (row > 0) 
                         {
                             message = "HOD Email updated and saved successfully.";
                             count=count+1;
                         }
                         
                     }
                     catch(Exception ex)
                     {
                   	  message = "ERROR :"+ ex.getMessage() ;
                   	  ex.printStackTrace();
                     }
                }
               
                if (Uname.isEmpty()== false) 
                {
                	
                   
                    String sql2 = "Update hod set username = ? where department=?";
                    
                     try {
                         // connects to the database
                         Class.forName("com.mysql.jdbc.Driver");
                         Connection con = DriverManager.getConnection(dbURL, dbUser, dbPass);
                         PreparedStatement pst = con.prepareStatement(sql2);
                         
                         pst.setString(1, Uname);
                         pst.setString(2, dept);
                         
                         System.out.println(Uname);
                         
                         int row = pst.executeUpdate();
                         if (row > 0) 
                         {
                             message = "HOD Username updated and saved successfully.";
                             count = count+1;
                         }
                         
                     }
                     catch(Exception ex)
                     {
                   	  message = "ERROR :"+ ex.getMessage() ;
                   	  ex.printStackTrace();
                     }
                }
                   
                     if (Pass.isEmpty()== false) 
                     {
                     	
                        
                         String sql3 = "Update hod set password = ? where department=?";
                         
                          try {
                              // connects to the database
                              Class.forName("com.mysql.jdbc.Driver");
                              Connection con = DriverManager.getConnection(dbURL, dbUser, dbPass);
                              PreparedStatement pst = con.prepareStatement(sql3);
                              
                              pst.setString(1, Pass);
                              pst.setString(2, dept);
                              
                              System.out.println(Pass);
                              
                              int row = pst.executeUpdate();
                              if (row > 0) 
                              {
                                  message = "HOD Password updated and saved successfully.";
                                  count=count+1;
                              }
                              
                          }
                          catch(Exception ex)
                          {
                        	  message = "ERROR :"+ ex.getMessage() ;
                        	  ex.printStackTrace();
                          }
                     }
                    
                     
                     InputStream inputStreamP = null;
                     Part filePartP = request.getPart("profile");
                     
                     if(filePartP.getSize() != 0 )
                     {
                      if (filePartP.getSize() < 1048576) 
                      {
                      	
                          inputStreamP = filePartP.getInputStream();
                          String sql4 = "Update hod set profile = ? where department=?";
                          
                           try {
                               // connects to the database
                               Class.forName("com.mysql.jdbc.Driver");
                               Connection con = DriverManager.getConnection(dbURL, dbUser, dbPass);
                               PreparedStatement pst = con.prepareStatement(sql4);
                               
                               pst.setBlob(1, inputStreamP);
                               pst.setString(2, dept);
                               
                               int row = pst.executeUpdate();
                               if (row > 0) 
                               {
                                   message = "HOD Profile Picture updated and saved successfully.";
                                   count = count + 1;
                               }
                               
                           }
                           catch(Exception ex)
                           {
                         	  message = "ERROR :"+ ex.getMessage() ;
                         	  ex.printStackTrace();
                           }                 
                      }
                      else
                      {
                      	message = "Profile picture size is too Big.";
                          return;
                      }
                     }
                   
                     if(count == 0)
                     {
                    	 message = "Please enter the detail to Update.";
                     }
                     else
                     {
                    	 count = 0;
                     }
           request.setAttribute("Message", message);
           getServletContext().getRequestDispatcher("/MessageH.jsp").forward(request, response); 
    }
}