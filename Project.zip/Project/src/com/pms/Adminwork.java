package com.pms;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/adminwork")

public class Adminwork extends HttpServlet
{

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String button = request.getParameter("button");
		if (button == null) 
		{
		   response.sendRedirect("AdminWel.jsp");
		} 
		else if (button.equals("Add HOD")) 
		{
		    response.sendRedirect("Addhod.jsp");
		}
		else if (button.equals("Remove HOD")) 
		{
			response.sendRedirect("Removehod.jsp");
		} 
		else if( button.equals("Logout"))
		{
			HttpSession session = request.getSession();
			session.removeAttribute("username");
			session.invalidate();
			
			response.sendRedirect("adminlogin.html");
		}
	}
}
