package com.pms;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet("/addhod")
@MultipartConfig(maxFileSize = 16177215)	// upload file's size up to 16MB

public class Addhod extends HttpServlet
{
	private String dbURL = "jdbc:mysql://localhost:3306/pms";
    private String dbUser = "root";
    private String dbPass = "";
    
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException 
    {
    	PrintWriter writer = response.getWriter();
    	
    	String Name = request.getParameter("name");
        String Department = request.getParameter("Department");
        String Email = request.getParameter("email");
        String Uname = request.getParameter("uname");
        String Pass = request.getParameter("pass");
        
        InputStream inputStreamP = null;
        Part filePartP = request.getPart("profile");
        
        if(filePartP != null)
        {
         if (filePartP.getSize() < 1048576) 
         {
         	
             inputStreamP = filePartP.getInputStream();
         }
         else
         {
         	writer.println("\nProfile Picture Size Too Big.");
             return;
         }
        }
        
        String message = null;
        
        try {
            // connects to the database
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection(dbURL, dbUser, dbPass);
            
            String sql = "INSERT INTO hod (username, password, department, name, email, profile) values (?, ?, ?, ?, ?, ?)";
            
            PreparedStatement pst = con.prepareStatement(sql);
            
            pst.setString(1, Uname);
            pst.setString(2, Pass);
            pst.setString(3, Department);
            pst.setString(4, Name);
            pst.setString(5, Email);
            
            pst.setBlob(6, inputStreamP);
            
            int row = pst.executeUpdate();
            if (row > 0) 
            {
                message = "HOD Data and Profile Picture uploaded and saved successfully.";
            }
        }
        catch (Exception ex) 
        {
        	/*message = "ERROR :"+ ex.getMessage() ;*/
        	message = "ERROR : HOD of this Department already exists,</br> If you want to add another Please Remove the earlier one. ";
    		ex.printStackTrace();		
        		
        }
        
        request.setAttribute("Message", message);
           
        getServletContext().getRequestDispatcher("/MessageA.jsp").forward(request, response);
            
        
        
    }

}
