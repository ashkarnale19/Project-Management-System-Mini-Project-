package com.pms.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class LoginDaoHod 
{
	String url="jdbc:mysql://localhost:3306/pms";
	String username = "root";
	String password = "";
	String sql ="select username,password,department from hod where username=? and password=? and department=? ";
	
	public boolean check(String uname, String pass, String dept )
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url,username,password);
			PreparedStatement st = con.prepareStatement(sql);
			st.setString(1, uname);
			st.setString(2, pass);
			st.setString(3, dept);
			ResultSet rs = st.executeQuery();
			
			if(rs.next())
			{
				return true;
			}
			
		} 
		catch (Exception e) 
		{
		
			e.printStackTrace();
		}	
		return false;
	}

}
